/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    adc.c
  * @brief   This file provides code for the configuration
  *          of the ADC instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "adc.h"

/* USER CODE BEGIN 0 */
#include<math.h>
#include"stdint.h"
static const float A =7.47553127e-04;//0.000747557f;//-5.07074942e-03f;//8.2852734e-04f;  ////0.000827124;
static const float B =2.111798741e-04;//0.000211179f;//2.06812884e-04;//// 0.0002088;//
static const float C =1.14789e-7f;//9.467004838e-08;// //8.05978E-8;//

float temp_deg=0.00;
uint16_t avg_raw=0;


/* USER CODE END 0 */

ADC_HandleTypeDef hadc1;

/* ADC1 init function */
void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */

  /* USER CODE END ADC1_Init 1 */

  /** Configure the global features of the ADC (Clock, Resolution, Data Alignment and number of conversion)
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_SYNC_PCLK_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_12B;
  hadc1.Init.DataAlign = ADC_DATAALIGN_RIGHT;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.LowPowerAutoPowerOff = DISABLE;
  hadc1.Init.ContinuousConvMode = ENABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.ExternalTrigConv = ADC_SOFTWARE_START;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_NONE;
  hadc1.Init.DMAContinuousRequests = DISABLE;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.SamplingTimeCommon1 = ADC_SAMPLETIME_12CYCLES_5;
  hadc1.Init.SamplingTimeCommon2 = ADC_SAMPLETIME_7CYCLES_5;
  hadc1.Init.OversamplingMode = DISABLE;
  hadc1.Init.TriggerFrequencyMode = ADC_TRIGGER_FREQ_HIGH;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLINGTIME_COMMON_1;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}

void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */
    /* ADC1 clock enable */
    __HAL_RCC_ADC_CLK_ENABLE();

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**ADC1 GPIO Configuration
    PA0     ------> ADC1_IN0
    PA4     ------> ADC1_IN4
    */
    GPIO_InitStruct.Pin = GPIO_PIN_0|BAT_VOL_DET_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /* USER CODE BEGIN ADC1_MspInit 1 */

  /* USER CODE END ADC1_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* adcHandle)
{

  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspDeInit 0 */

  /* USER CODE END ADC1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_ADC_CLK_DISABLE();

    /**ADC1 GPIO Configuration
    PA0     ------> ADC1_IN0
    PA4     ------> ADC1_IN4
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_0|BAT_VOL_DET_Pin);

  /* USER CODE BEGIN ADC1_MspDeInit 1 */

  /* USER CODE END ADC1_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

/*----------------------------------------------------------------------------------------------------------
 * Function Name:- read_temperature_celsius
 * Function  design to take the thermister reading to the ADC pin connected in series with the 100K resistor
 * Reads an MF52-100K-3950 NTC thermistor with ADC1
 * return type:- float (temperature readings)      */
//------------------------------------------------------------------------------------------------------------
float read_temperature_celsius(void)
{
	ADC_ChannelConfTypeDef sConfig = {0};

	  sConfig.Channel = ADC_CHANNEL_0;  // PA0 - Thermistor
	  sConfig.Rank = ADC_REGULAR_RANK_1;
	  sConfig.SamplingTime = ADC_SAMPLINGTIME_COMMON_1;

 if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }

  HAL_ADC_Start(&hadc1); //start ADC
  uint32_t raw=0;
  for(uint8_t i=0;i<100;i++) // take the samples for Average
  {
  uint16_t tmp_raw = HAL_ADC_GetValue(&hadc1);
  raw=raw+tmp_raw;
  HAL_Delay(2);
  }
  HAL_ADC_Stop(&hadc1); // stop ADC
  avg_raw=raw/100;

  float v_ntc = (avg_raw / ADC_MAX) * VREF; //NTC voltage calculation for temperature
  if (v_ntc <= 0.0f || v_ntc >= VREF)
    return -273.15f;

  float r_ntc = (v_ntc * R_FIXED) / (VREF - v_ntc);
  float log_r = logf(r_ntc);
  float inv_t = A + B * log_r + C * powf(log_r, 3);
  temp_deg=(1.0f / inv_t) - 273.15f;
  return temp_deg;


}

/*----------------------------------------------------------------------------------------------------------
 * Function Name:- read_battery_voltage
 * Function  design to take the battery voltage reading from the ADC1 channel 4 connected in series with the 75K and 20k resistor
 * Reads battery voltage with ADC1 CH4
 * return type:- float (voltage readings)      */
//------------------------------------------------------------------------------------------------------------
float read_battery_voltage(void)
{

	 ADC_ChannelConfTypeDef sConfig = {0};

	  sConfig.Channel = ADC_CHANNEL_4; // PA4 = Battery sense
	  sConfig.Rank = ADC_REGULAR_RANK_1;
	  sConfig.SamplingTime = ADC_SAMPLINGTIME_COMMON_1;
	  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	  {
	    Error_Handler();
	  }

	  HAL_ADC_Start(&hadc1); //start ADC1 channel4

	  uint32_t raw_sum = 0;
	  for (uint8_t i = 0; i < 100; i++) //to average the value received
	  {
	    HAL_ADC_PollForConversion(&hadc1, HAL_MAX_DELAY);
	    uint16_t tmp_bat_raw=HAL_ADC_GetValue(&hadc1);
	    raw_sum=raw_sum+tmp_bat_raw;
	    HAL_Delay(2); // Optional: allow voltage to settle/stabilize
	  }

	  HAL_ADC_Stop(&hadc1);

	  float avg_raw_2 = raw_sum / 100.0f;
	  float voltage = (avg_raw_2 / ADC_MAX) * VREF;

	  voltage *= BAT_DIVIDER_RATIO;  // Adjust for voltage divider

	  return voltage;
}
/* USER CODE END 1 */
