/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    tim.c
  * @brief   This file provides code for the configuration
  *          of the TIM instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "tim.h"

/* USER CODE BEGIN 0 */
#define PWM_MAX 25000  // Max PWM value (for smooth fade)
#define STEP     500 // Step size for fade (smaller = smoother)
#define DELAY   10    // Delay in ms between steps
/* USER CODE END 0 */

TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

/* TIM1 init function */
void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};
  TIM_BreakDeadTimeConfigTypeDef sBreakDeadTimeConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterOutputTrigger2 = TIM_TRGO2_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  sConfigOC.OCIdleState = TIM_OCIDLESTATE_RESET;
  sConfigOC.OCNIdleState = TIM_OCNIDLESTATE_RESET;
  if (HAL_TIM_PWM_ConfigChannel(&htim1, &sConfigOC, TIM_CHANNEL_4) != HAL_OK)
  {
    Error_Handler();
  }
  sBreakDeadTimeConfig.OffStateRunMode = TIM_OSSR_DISABLE;
  sBreakDeadTimeConfig.OffStateIDLEMode = TIM_OSSI_DISABLE;
  sBreakDeadTimeConfig.LockLevel = TIM_LOCKLEVEL_OFF;
  sBreakDeadTimeConfig.DeadTime = 0;
  sBreakDeadTimeConfig.BreakState = TIM_BREAK_DISABLE;
  sBreakDeadTimeConfig.BreakPolarity = TIM_BREAKPOLARITY_HIGH;
  sBreakDeadTimeConfig.BreakFilter = 0;
  sBreakDeadTimeConfig.BreakAFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.Break2State = TIM_BREAK2_DISABLE;
  sBreakDeadTimeConfig.Break2Polarity = TIM_BREAK2POLARITY_HIGH;
  sBreakDeadTimeConfig.Break2Filter = 0;
  sBreakDeadTimeConfig.Break2AFMode = TIM_BREAK_AFMODE_INPUT;
  sBreakDeadTimeConfig.AutomaticOutput = TIM_AUTOMATICOUTPUT_DISABLE;
  if (HAL_TIMEx_ConfigBreakDeadTime(&htim1, &sBreakDeadTimeConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */
  HAL_TIM_MspPostInit(&htim1);

}
/* TIM3 init function */
void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim3, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */
  HAL_TIM_MspPostInit(&htim3);

}

void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef* tim_pwmHandle)
{

  if(tim_pwmHandle->Instance==TIM1)
  {
  /* USER CODE BEGIN TIM1_MspInit 0 */

  /* USER CODE END TIM1_MspInit 0 */
    /* TIM1 clock enable */
    __HAL_RCC_TIM1_CLK_ENABLE();
  /* USER CODE BEGIN TIM1_MspInit 1 */

  /* USER CODE END TIM1_MspInit 1 */
  }
  else if(tim_pwmHandle->Instance==TIM3)
  {
  /* USER CODE BEGIN TIM3_MspInit 0 */

  /* USER CODE END TIM3_MspInit 0 */
    /* TIM3 clock enable */
    __HAL_RCC_TIM3_CLK_ENABLE();
  /* USER CODE BEGIN TIM3_MspInit 1 */

  /* USER CODE END TIM3_MspInit 1 */
  }
}
void HAL_TIM_MspPostInit(TIM_HandleTypeDef* timHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(timHandle->Instance==TIM1)
  {
  /* USER CODE BEGIN TIM1_MspPostInit 0 */

  /* USER CODE END TIM1_MspPostInit 0 */
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**TIM1 GPIO Configuration
    PA11 [PA9]     ------> TIM1_CH4
    */
    GPIO_InitStruct.Pin = GREEN_PWM_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF2_TIM1;
    HAL_GPIO_Init(GREEN_PWM_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN TIM1_MspPostInit 1 */

  /* USER CODE END TIM1_MspPostInit 1 */
  }
  else if(timHandle->Instance==TIM3)
  {
  /* USER CODE BEGIN TIM3_MspPostInit 0 */

  /* USER CODE END TIM3_MspPostInit 0 */

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**TIM3 GPIO Configuration
    PA6     ------> TIM3_CH1
    */
    GPIO_InitStruct.Pin = RED_PWM_Pin;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF1_TIM3;
    HAL_GPIO_Init(RED_PWM_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN TIM3_MspPostInit 1 */

  /* USER CODE END TIM3_MspPostInit 1 */
  }

}

void HAL_TIM_PWM_MspDeInit(TIM_HandleTypeDef* tim_pwmHandle)
{

  if(tim_pwmHandle->Instance==TIM1)
  {
  /* USER CODE BEGIN TIM1_MspDeInit 0 */

  /* USER CODE END TIM1_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM1_CLK_DISABLE();
  /* USER CODE BEGIN TIM1_MspDeInit 1 */

  /* USER CODE END TIM1_MspDeInit 1 */
  }
  else if(tim_pwmHandle->Instance==TIM3)
  {
  /* USER CODE BEGIN TIM3_MspDeInit 0 */

  /* USER CODE END TIM3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_TIM3_CLK_DISABLE();
  /* USER CODE BEGIN TIM3_MspDeInit 1 */

  /* USER CODE END TIM3_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */
void LED_GREEN_PWM(void)
{
	 HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);  // Start PWM
	 for(uint8_t i=0;i<16;i++)
	 {
	 for (uint16_t pwm = 0; pwm <= PWM_MAX; pwm += STEP)
	    {
	      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm);
	      HAL_Delay(20);
	    }

	    // Fade out
	    for (int16_t pwm = PWM_MAX; pwm >= 0; pwm -= STEP)
	    {
	      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm);
	      HAL_Delay(2);
}
}
	 HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_4);  // Start PWM
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);//stop the pnp transistor
}

/* Below function designed to drive the LED in the FADE IN Fade OUT mode using the PWM at TIM1 and TIM3          */
void LED_RED_PWM(void)
	    {
	    	 HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // Start PWM
	    	 for(uint8_t i=0;i<16;i++)
	    	 { //fade in
	    	 for (uint16_t pwm = 0; pwm <= PWM_MAX; pwm += STEP)
	    	    {
	    	      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
	    	      HAL_Delay(20);
	    	    }

	    	    // Fade out
	    	    for (int16_t pwm = PWM_MAX; pwm >= 0; pwm -= STEP)
	    	    {
	    	      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
	    	      HAL_Delay(2);
	    }
	    	 }
	    	 HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);  // Stop PWM
	    	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);// stop the red led transistor PNP
	    }
void LED_YELLOW_PWM(void)
{
	 HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // Start PWM
	 HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);  // Start PWM

		    	 for(uint8_t i=0;i<16;i++)
		    	 {
		    		 // fade in
		    	 for (uint16_t pwm = 0; pwm <= PWM_MAX; pwm += STEP)
		    	    {
		    	      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
		    	      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm);
		    	      HAL_Delay(20);
		    	    }

		    	    // Fade out
 		    	    for (int16_t pwm = PWM_MAX; pwm >= 0; pwm -= STEP)
		    	    {
		    	      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
		    	      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm);
		    	      HAL_Delay(2);
		    }
		    	 }
		    	 HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);  // Stop PWM
		    	 HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_4);  // Stop PWM
		    	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);// stop the red led transistor PNP
		    	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);//stop the pnp transistor

}

void BLINK_BLUE(void)
{
	for(uint8_t i=16;i>0;i--)
	{
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_RESET);
	 HAL_Delay(i*20);
	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_5, GPIO_PIN_SET);
		 HAL_Delay(i*30);
	}
}

/*----------------------------------------------------------------------------------------------------------
 * Function Name:- set_led_from_temp(float t_c)
 * Function  design to indicate, that the temperature inside the lid .
 * return type:- float     */
//------------------------------------------------------------------------------------------------------------
void set_led_from_temp(float t_c)
{

	// DO NOT INITIALIZE THE PA13 (SWDIO) & PA14(SWCLK)

    /* Wipe previous state */

	if (t_c < 25.0f)    //  24-26 °C → blue
		BLINK_BLUE();


    else if (t_c < 30.0f)      /* 25-30 °C → green ambient room temp */
        LED_GREEN_PWM();


    else if (t_c < 42.0f)    /* 30-42 °C → yellow (R+G) bit hot */
    	LED_YELLOW_PWM();

    else                       /* ≥ 42 °C → red fully hot*/
    	LED_RED_PWM();;
}
/*----------------------------------------------------------------------------------------------------------
 * Function Name:- battery_low_alarm()
 * Function  design to indicate, that the battery is lower than the threshold
 * return type:- void     */
//------------------------------------------------------------------------------------------------------------
void battery_low_alarm(void)
{
	HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);  // Start PWM
		    	 for(uint8_t i=0;i<10;i++)
		    	 { //fade in
		    	 for (uint16_t pwm = 0; pwm <= 15000; pwm += STEP)
		    	    {
		    	      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
		    	      HAL_Delay(2);
		    	    }

		    	    // Fade out
		    	    for (int16_t pwm = 15000; pwm >= 0; pwm -= STEP)
		    	    {
		    	      __HAL_TIM_SET_COMPARE(&htim3, TIM_CHANNEL_1, pwm);
		    	      HAL_Delay(2);
		    	    }
		    	 }
		    	 HAL_TIM_PWM_Stop(&htim3, TIM_CHANNEL_1);  // Stop PWM
		    	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_6, GPIO_PIN_SET);// stop the red led PNP transistor

}
/*----------------------------------------------------------------------------------------------------------
 * Function Name:- battery_charging()
 * Function  design to indicate if the battery is charging or not by detecting the type c input using the divider of 100k and 150K
 * return type:- void     */
//------------------------------------------------------------------------------------------------------------
void battery_charging(void)
{
	HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);  // Start PWM when the battery is charging.
			    	 for(uint8_t i=0;i<5;i++)
			    	 { //fade in
			    	 for (uint16_t pwm = 10000; pwm <=500; pwm += STEP)
			    	    {
			    	      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm);
			    	      HAL_Delay(25);
			    	    }

			    	    // Fade out
			    	    for (int16_t pwm = 10000; pwm >= 0; pwm -= STEP)
			    	    {
			    	      __HAL_TIM_SET_COMPARE(&htim1, TIM_CHANNEL_4, pwm);
			    	      HAL_Delay(25);
			    	    }
			    	 }
			    	 HAL_Delay(1500);
			    	 HAL_TIM_PWM_Stop(&htim1, TIM_CHANNEL_4);  // Stop PWM
			    	 HAL_GPIO_WritePin(GPIOA, GPIO_PIN_11, GPIO_PIN_SET);//stop the green led PNP transistor
}
/* USER CODE END 1 */
